<?php

class Main extends CI_Controller {
    public function index() {
        echo "I am Main class!";
    }
    public function hello() {
        echo "Hello World!";
    }

    public function say() {
        echo "Hi!";
     function hi() {
            echo "Hi!";
        }
    }

    public function say_anything($message) {
        echo strtoupper($message);
    }

    public function danger() {
        redirect('/main');
    }
}