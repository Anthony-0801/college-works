<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Anthony Cabulang">
    <title>Feedback Form</title>
    <link rel="stylesheet" href="<?= asset_url(); ?>css/styles.css">
</head>
<body>
    <main>
        <section>
            <h1>Feedback Form</h1>
            <form action="<?= site_url('result') ?>" method="POST">
                <label for="name">Name:</label>
                <input type="text" name="name" id="name">

                <label for="course">Course Title:</label>
                <select name="course" id="course">
                    <option value="Introduction">Introduction</option>
                    <option value="Web Fundamentals">Web Fundamentals</option>
                    <option value="PHP Track">PHP Track</option>
                    <option value="Basic Algorithm">Basic Algorithm</option>
                    <option value="Communication">Communication</option>
                </select>

                <label for="score">Given Score (1-10): </label>
                <select name="score" id="score">
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                </select>

                <label for="reason">Reason:</label>
                <textarea name="reason" id="reason" rows="4" cols="46"></textarea>
            
                <input type="hidden" name="action" value="feedback">
                <input type="submit" value="Submit Feedback">
            </form>
        </section>
    </main>
</body>
</html>