<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Anthony Cabulang">
    <title>Feedback Form</title>
    <link rel="stylesheet" href="<?= asset_url(); ?>css/styles.css">
</head>
<body>
    <main>
    <section>
            <h1>Submitted Entry</h1>
            <p>Your Name (optional): <?= $name ?></p>
            <p>Course Title: <?= $course ?></p>
            <p>Score: <?= $score ?>pts</p>
            <p>Reason: <?= $reason ?></p>
            <div>
                <a href="<?=base_url()?>">Return</a>
            </div>
    </section>
    </main>
</body>
</html>