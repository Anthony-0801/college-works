<?php
//Anthony A. Cabulang
//Batch 5 OJT February Cohort

class Feedback extends CI_Controller {
    public function index() {
        $this->load->view('feedback/index');
    }

    public function result() {
        if($this->input->post('action') == 'feedback') {
            $name = $this->input->post('name');
            $course = $this->input->post('course');
            $score = $this->input->post('score');
            $reason = $this->input->post('reason');

            $data['name'] = $name;
            $data['course'] = $course;
            $data['score'] = $score;
            $data['reason'] = $reason;

            $this->load->view('feedback/result', $data);
        }
    }
}