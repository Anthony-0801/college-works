<?php
//Anthony A. Cabulang
//Batch 5 OJT February Cohort

class Countdown extends CI_Controller {
    public function main() {
        // Get the current date and time
        $current_datetime = new DateTime();

        // Calculate the remaining seconds until midnight
        $midnight = new DateTime('tomorrow midnight');
        $remaining_seconds = $midnight->getTimestamp() - $current_datetime->getTimestamp();

        // Pass data to the view
        $data['current_datetime'] = $current_datetime->format('F d, Y');
        $data['remaining_seconds'] = $remaining_seconds;

        $this->load->view('countdown/main', $data);
    }
}