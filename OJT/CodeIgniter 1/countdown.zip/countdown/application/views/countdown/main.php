<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Anthony Cabulang">
    <title>Countdown</title>
    <link rel="stylesheet" href="<?= asset_url(); ?>css/styles.css">
</head>
<body>
    <main>
    <h1>Countdown before day ends!</h1>
    <section>
        <h2> <?= $remaining_seconds ?> seconds</h2>
        <h2><?= $current_datetime ?></h2>
    </section>
 
    </main>
</body>
</html>