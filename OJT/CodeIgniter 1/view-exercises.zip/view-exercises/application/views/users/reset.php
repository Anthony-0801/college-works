<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Anthony Cabulang">
    <title>Users</title>
    <link rel="stylesheet" href="<?= asset_url(); ?>css/styles.css">
</head>
<body>
    <main>
    <h1>The session has been reset.</h1>
    <form action="<?= site_url('users/reset') ?>" method="POST">
        <input type="hidden" name="action" value="reset">
        <input type="submit" value="Visit Site Count">
    </form>
    </form>
    </main>
</body>
</html>