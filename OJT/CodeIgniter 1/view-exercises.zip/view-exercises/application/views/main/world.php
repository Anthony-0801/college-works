<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Anthony Cabulang">
    <title>Some Beautiful Places in the World</title>
    <link rel="stylesheet" href="<?= asset_url(); ?>css/styles.css">
</head>
<body>
    <main>
    <h1>Some Beautiful Places in the World</h1>
    <ul>
        <li>
            <img src="<?= asset_url(); ?>images/amazon.jpg" alt="amazon river">
        </li>

        <li>
            <img src="<?= asset_url(); ?>images/venezuela.jpg" alt="venezuela angel falls">
        </li>

        <li>
            <img src="<?= asset_url(); ?>images/japan.jpg" alt="japan bamboo forest">
        </li>
    </main>
</body>
</html>