<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Anthony Cabulang">
    <title>Awesome Ninjas</title>
    <link rel="stylesheet" href="<?= asset_url(); ?>css/styles.css">
</head>
<body>
    <main>
    <h1>Awesome Ninjas</h1>
    <ul>
        <li>
<?php for ($i = 0; $i < $number_of_ninjas; $i++) { ?>
          <img src="<?= asset_url(); ?>images/ninja3.jpg" alt="ninja">
<?php } ?>
        </li>
    </main>
</body>
</html>