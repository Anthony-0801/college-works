<?php
//Anthony A. Cabulang
//Batch 5 OJT February Cohort
class Main extends CI_Controller {
    public function index() {
        echo "I am Main class!";
    }
    public function hello() {
        echo "Hello World!";
    }

    public function say() {
     function hi() {
            echo "Hi!";
        }
        hi();
    }

    public function say_anything($message) {
        echo strtoupper($message);
    }

    public function danger() {
        redirect(base_url());
    }

    public function world() {
        $this->load->view('main/world');
    }

    public function ninjas($number = 5) {
        $data['number_of_ninjas'] = $number;
        $this->load->view('main/ninjas', $data);
    }

}