<?php
//Anthony A. Cabulang
//Batch 5 OJT February Cohort
class Users extends CI_Controller {

    public function index() {
        $this->load->view('users/index');
    }

    public function new() {
        if($this->input->post('action') == 'create') {
            $this->load->view('users/create');
        } else {
            $this->load->view('users/new');
        }
    }

    public function create() {
        $this->load->view('users/create');
    }

    public function count() {
        $this->load->library('session');

        //Get the count from the session
        $count = $this->session->userdata('count');

        //Increment the count
        $count++;
        $this->session->set_userdata('count', $count);

        //Pass the count to the viewfile
        $data['count']=$count;
        $this->load->view('users/count', $data);
    }

    public function reset() {
        $this->load->library('session');

        //Reset the count
        $this->session->set_userdata('count', 0);
        $this->load->view('users/reset');

        if($this->input->post('action') == 'reset') {
            redirect('users/count');
        }
    }

    public function say($message, $times = 1) {
        //Pass into session flashdata if the URL does not meet the requirements
        if($times < 0 || !is_numeric($times)) {
            $this->session->set_flashdata('error', "Sorry. This URL does not meet our requirements.");
            $message = $this->session->flashdata('error');
        }
        $data['message'] = $message;
        $data['times'] = $times;
        $this->load->view('users/say', $data);
    }
    
    public function mprep()
     {
          $view_data = array(
               'name' => "Michael Choi",
               'age'  => 40,
               'location' => "Seattle, WA",
               'hobbies' => array( "Basketball", "Soccer", "Coding", "Teaching", "Kdramas")
           );
           $this->load->view('users/mprep', $view_data);
     }
}