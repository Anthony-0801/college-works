<html>
    <head>
        <meta name="author" content="Anthony A. Cabulang">
        <title>Bingo</title>
        <link rel="stylesheet" href="bingo.css">
    </head>
    <body>
        <h1>BINGO</h1>
        <table>
<?php for ($i = 2; $i <= 6; $i++) { ?>
            <tr>
<?php       for ($j = 1; $j <= 5; $j++) {
            $number = $i * $j;
            $color = ($i + $j) % 2 === 0 ? 'color_1' : 'color_2';
?>
                <td class='<?=$color?>'><?=$number?></td>
<?php        } ?>
            </tr>
<?php  }
?>
        </table>
    </body>
</html>
